//app.js
App({
  globalData: {
  },

  onLaunch: function () {
    wx.getStorage({
      key: 'history_index',
      fail: () => {
        wx.setStorage({
          key: 'history_index',
          data: 0,
          success:()=>{console.log('history_index initialized')},
          fail: () => {console.log('history_index initialize failed')},
        });
      },
    });
  }
})