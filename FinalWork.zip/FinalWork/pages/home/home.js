Page({
  data: {
    birthday:"December 14,2019",
    days:"",
    msOfOneDay:86400000
  },

  onLoad: function (options) {
    //显示小程序的年龄
    var that=this
    var today=new Date();
    that.setData({birthday:Date.parse(that.data.birthday)});
    var tmpDays=Math.round((today.getTime()-that.data.birthday)/that.data.msOfOneDay);
    that.setData({days:tmpDays});
  },

  record:function (e) {
    wx:wx.navigateTo({
      url: 'record/record',
    });
  },
  history:function (e) {
    wx:wx.navigateTo({
      url: 'history/history',
    });
  }
})