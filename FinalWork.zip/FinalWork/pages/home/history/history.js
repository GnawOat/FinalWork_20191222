// pages/home/history/history.js
Page({
  data: {
    index:0,
    history:[]
  },
  onLoad: function (options) {
      var index=wx.getStorageSync('history_index');
      this.setData({
        'index':index
      })
      for (let i = 1; i < index+1; i++) {
        var element=wx.getStorageSync('history_index['+i+']');
        var history='history['+(i-1)+']'
        this.setData({
          [history]:element
        })
      }
      console.log(this.data.history);
      
      
  },

  delete:function (e) {
    wx.showModal({
      title: '删除数据',
      content: '本条数据将被永久删除!',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#edece8',
      confirmText: '确定',
      confirmColor: '#f25214',
      success: (result) => {
        if (result.confirm) {
          var index=e.currentTarget.dataset.index+1
          for (let i = index; i < this.data.index; i++) {
            const element = wx.getStorageSync('history_index['+(i+1)+']');
            wx.setStorageSync('history_index['+i+']', element);
          }
          wx.removeStorageSync('history_index['+this.data.index+']');
          wx.setStorageSync('history_index', this.data.index-1);
          wx.showToast({
            title: '数据已删除',
            icon: 'success',
            image: '',
            duration: 1500,
            mask: false,
            success: (result) => {
              
            },
            fail: () => {},
            complete: () => {}
          });
          this.onLoad();
        }
      },
    });
      

    console.log(wx.getStorageInfoSync());
  }
})