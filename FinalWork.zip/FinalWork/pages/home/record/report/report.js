// pages/home/record/report/report.js
Page({
  data: {
    rate_value:0,
    add_score:0,
    global_value:'输入错误',
    mottos:'none',
    writer:'noname',
  },
  toHome:function () {
    wx.switchTab({
      url: '../../home',
    });
      
  },
  toHistory:function (e) {
    wx.redirectTo({
      url: '../../history/history',
    });
      
  },
  
  onLoad: function (options) {
    {// about value
    let tmp_rate=parseFloat(options.value);
    var tmp=Math.round(tmp_rate*0.3)
    if (Number.isInteger(tmp)) {
      var total=wx.getStorageSync('total_scores')
      wx.setStorageSync('total_scores',total+tmp);
      this.setData({
        global_value:wx.getStorageSync('total_scores')
      })
    }
    else{      
      console.log('input err');
    } 
    var total=wx.getStorageSync('total_scores');
    this.setData({
      rate_value:tmp_rate,
      add_score:tmp,
    })    
    }
    {//mottos
      var motto=this.data.add_score
      let that=this;
      if (motto<1) {
        that.setData({
          mottos:'能控制自己的人，才能掌握自己的命运。',
          writer:'黄嘉俊'
        })
      }
      else if (motto<3) {
        that.setData({
          mottos:'过去属于死神，未来属于你自己。',
          writer:'雪莱'
        })
      }
      else if (motto<5) {
        that.setData({
          mottos:'你明白，人的一生，既不是人们想象的那么好，也不是那么坏。',
          writer:'莫泊桑'
        })
      }
      else if (motto<7) {
        that.setData({
          mottos:'谁若游戏人生，他就一事无成；谁不主宰自己，永远是一个奴隶。',
          writer:'歌德'
        })
      }
      else if (motto<9) {
        that.setData({
          mottos:'志不强者智不达。',
          writer:'墨翟'
        })
      }
      else if (motto<11) {
        that.setData({
          mottos:'如月之恒，如日之升。',
          writer:'《诗经·小雅·无保》'
        })
      }
      else if (motto<13){
        that.setData({
          mottos:'梦是一种欲望，想是一种行动。',
          writer:'佚名'
        })
      }
      else if (motto<15) {
        that.setData({
          mottos:'梦想一旦被付诸行动，就会变得神圣。',
          writer:'阿·安·普罗克特'
        })
      }
      else if (motto<17) {
        that.setData({
          mottos:'先把人生变成一个科学的梦，然后再把梦变成现实。',
          writer:'佚名'
        })
      }
      else if (motto<19) {
        that.setData({
          mottos:'要抒写自己梦想的人，反而更应该清醒。',
          writer:'佚名'
        })
      }
      else if (motto<21) {
        that.setData({
          mottos:'我们富了口袋，但穷了脑袋；我们有梦想，但缺少了思想。',
          writer:'佚名'
        })
      }
      else if (motto<23) {
        that.setData({
          mottos:'不经一翻彻骨寒,怎得梅花扑鼻香。',
          writer:'唐 · 黄蘖'
        })
      }
      else{
        that.setData({
          mottos:'孤舟蓑笠翁，独钓寒江雪。',
          writer:' 唐 · 柳宗元'
        })
      }
    }
    
  },

})