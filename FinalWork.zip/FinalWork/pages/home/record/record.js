// pages/home/record/record.js
Page({
  data: {
    storage:{
      history_index:0,
      history_upload:{
        id:0,
        date:[0,0,0,0,0,0],
        study_hour:0,
        study_min:0,
        rate_value:0,
        score:0,
        self_evaluate:'没有自我评价',
      }
    },
    hide_study:'display:none',
    hide_life:'display:none',
    add_hide:'none',
    minus_hide:'none',
    rate_value:0,
    study_time_total:0,
    cstt_s:0,
    cstt_extra:0,
    formData:{
      study_time:{
        study_time_h:0,
        study_time_min:0
      },
      cstt_score:{
        add_s_radio1:0,
        add_s_radio2:0,
        cstt_add_sum:0,
        cstt_minus_sum:0,
        cstt_nx:[{nx:10},{nx:11},{nx:12},{nx:13},{nx:14},{nx:15}]
      },
      slider_s:0,
    },
    slider_control:{
      slider_unit:'没有自我评价',
      slider_res:'level 0',
    }
  },

//button area********************************
btnSubmit:function (e) {
  var that=this  
  {     //calculator
    var timeh=parseFloat(that.data.formData.study_time.study_time_h);
    var timemin=parseFloat(that.data.formData.study_time.study_time_min);
    var add_r1=parseFloat(that.data.formData.cstt_score.add_s_radio1);
    var add_r2=parseFloat(that.data.formData.cstt_score.add_s_radio2);
    var add_sum=parseFloat(that.data.formData.cstt_score.cstt_add_sum);
    var add_minus=parseFloat(that.data.formData.cstt_score.cstt_minus_sum);
    var n1=parseFloat(that.data.formData.cstt_score.cstt_nx[0].nx);
    var n2=parseFloat(that.data.formData.cstt_score.cstt_nx[1].nx);
    var n3=parseFloat(that.data.formData.cstt_score.cstt_nx[2].nx);
    var n4=parseFloat(that.data.formData.cstt_score.cstt_nx[3].nx);
    var n5=parseFloat(that.data.formData.cstt_score.cstt_nx[4].nx);
    var n6=parseFloat(that.data.formData.cstt_score.cstt_nx[5].nx);
  rate_calculator();
  function rate_calculator() {
    var kid=((n1/10)*(1+0.1*n5)*(1+0.1*n6)+n2+n3+n4)
    that.setData({
      study_time_total:timeh*60+timemin,
      cstt_extra:add_r1+add_r2+add_sum-add_minus
    })
    that.setData({
      cstt_s:10*Math.sqrt(kid/that.data.study_time_total)
    })
    that.setData({
      rate_value:Math.round(that.data.study_time_total*0.01+that.data.cstt_s+that.data.cstt_extra)
    })
  } 
  }
  var self_evaluate=this.data.slider_control.slider_unit
  var upload_evaluate='storage.history_upload.self_evaluate'
      this.setData({
        [upload_evaluate]:self_evaluate
      })
// set Storage
{ var now=new Date()
      var year=now.getFullYear()
      var month=now.getMonth()+1
      var day=now.getDate()
      var hour=now.getHours()
      var min=now.getMinutes()
      var second=now.getSeconds()
      var date='storage.history_upload.date'
      this.setData({
        [date]:[year,month,day,hour,min,second]
      })
          
 var that=this
      var history_index='storage.history_index'
      var history_id='storage.history_upload.id'
      this.setData({
        [history_index]:wx.getStorageSync('history_index'),
        [history_id]:wx.getStorageSync('history_index')+1,
      })
      var study_hour='storage.history_upload.study_hour';
      var study_min='storage.history_upload.study_min';
      var rate_value='storage.history_upload.rate_value';
      this.setData({
        [study_hour]:this.data.formData.study_time.study_time_h,
        [study_min]:this.data.formData.study_time.study_time_min,
        [rate_value]:this.data.rate_value,
      })
    }
    
  var index=this.data.storage.history_index+1;
      wx.setStorageSync('history_index['+[index]+']', this.data.storage.history_upload);
      wx.setStorageSync('history_index', index);
//pass value
  wx.redirectTo({
    url: 'report/report?value='+that.data.rate_value,
  });
},
btnReset:function (e) {
  wx.redirectTo({
    url: 'record',
  });
    
},

  
// form area*********************************
// form visual control***********
radio_change:function (e) {
  var that=this
  if(e.detail.value==="study"){ 
    that.setData({
      hide_study:"",
      hide_life:'display:none'
    })
  }
  else if(e.detail.value==="life"){
    that.setData({
      hide_life:"",
      hide_study:"display:none"
    })
  }
},
add_hider:function (e) {
  var that=this
  if(e.detail.value.length===2){
    that.setData({
      add_hide:'',
      minus_hide:''
    })
  }
  else if(e.detail.value[0]==='1'){
    that.setData({
      add_hide:'',
      minus_hide:'none'
    })
  }
  else if(e.detail.value[0]==='2'){
    that.setData({
      add_hide:'none',
      minus_hide:''
    })
  }
  else{
    that.setData({
      add_hide:'none',
      minus_hide:'none'
    })
  }
},

//form data area**************
checkbox_change1:function (e) {
  let that=this
  let sum='formData.cstt_score.cstt_add_sum'
  // console.log(e.detail.value);
  that.setData({
    [sum]:0
  })
  for (let index = 0; index < e.detail.value.length; index++) {
    const element = e.detail.value[index];
    var tmp=that.data.formData.cstt_score.cstt_add_sum
    that.data.formData.cstt_score.cstt_add_sum=parseFloat(tmp)+parseFloat(element)
  }
  // console.log(that.data.formData.cstt_score.cstt_add_sum);
},
checkbox_change2:function (e) {
  let that=this
  let sum='formData.cstt_score.cstt_minus_sum'
  // console.log(e.detail.value);
  that.setData({
    [sum]:0
  })
  for (let index = 0; index < e.detail.value.length; index++) {
    const element = e.detail.value[index];
    var tmp=that.data.formData.cstt_score.cstt_minus_sum
    that.data.formData.cstt_score.cstt_minus_sum=parseFloat(tmp)+parseFloat(element)
  }
  // console.log(that.data.formData.cstt_score.cstt_minus_sum);
},
add_s_radio1:function (e) {
  var that=this
  var tmp='formData.cstt_score.add_s_radio1'
  that.setData({
    [tmp]:e.detail.value
  })
  // console.log(that.data.formData.cstt_score.add_s_radio1);
},
add_s_radio2:function (e) {
  var that=this
  var tmp='formData.cstt_score.add_s_radio2'
  that.setData({
    [tmp]:e.detail.value
  })
  // console.log(that.data.formData.cstt_score.add_s_radio2);
},
input_input1:function (e) {
  let that=this
  let nx_index=parseInt(e.currentTarget.dataset.nx)-1
  let nx='formData.cstt_score.cstt_nx['+[nx_index]+'].nx'
  that.setData({
    [nx]:e.detail.value,
  })
    // console.log(that.data.formData.cstt_score.cstt_nx);
},

// study_time_input
st_input_reset1:function (e) {
  var that=this
  var tmpInt=parseInt(e.detail.value)
  var tmp='formData.study_time.study_time_h'
  that.setData({
    [tmp]:tmpInt
  })
  // console.log(that.data.formData.study_time.study_time_h);
},
st_input_reset2:function (e) {
  var that=this
  var tmpInt=parseInt(e.detail.value)
  var tmp='formData.study_time.study_time_min'
  that.setData({
    [tmp]:tmpInt
  })
  // console.log(tmpInt);
  // console.log(that.data.formData.study_time.study_time_min);
},

// study_self_slider
slider_study:function (e) {
  var that=this
  var tmp='formData.slider_s'
  that.setData({
    [tmp]:(e.detail.value+8)*0.1
  })
  // console.log(that.data.formData.slider_s);
},
slider_study_changing:function (e) {
  var that=this
  var unit='slider_control.slider_unit'
  var res='slider_control.slider_res'
  if (e.detail.value<25) {
    that.setData({
      [unit]:'菜！',
      [res]:'基本上一直在玩'
    })
  }
  else if (e.detail.value>=25&&e.detail.value<50) {
    that.setData({
      [unit]:'一般',
      [res]:'有点分心'
    })
  }
  else if (e.detail.value>=50&&e.detail.value<75) {
    that.setData({
      [unit]:'不错',
      [res]:'认真学习'
    })
  }
  else if (e.detail.value>=75&&e.detail.value<=100) {
    that.setData({
      [unit]:'棒呆！',
      [res]:'心无旁骛'
    })
  }
}
})