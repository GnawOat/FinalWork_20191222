// pages/page02/page02.js
Page({
  data: {
  },
  reset:function (e) {

    wx.showModal({
      title: '警告',
      content: '是否确认删除所有历史数据？',
      showCancel: true,
      cancelText: '取消',
      cancelColor: '#000000',
      confirmText: '确定',
      confirmColor: '#e64340',
      success: (result) => {
        if (result.confirm) {
          wx.clearStorage();
          wx.setStorageSync('history_index',0 );
          wx.setStorageSync('total_scores', 0);
          wx.showToast({
            title: '数据已删除',
            icon: 'success',
            image: '',
            duration: 1500,
            mask: false,
          });
            
        }
      },
    });
      

          
  }
})