// pages/page01/myScores/myScores.js
Page({
  data: {
    txt:'未初始化',
    writer:'作者',
    score:'未初始化'
  },

  onLoad: function (e) {
    var score=wx.getStorageSync('total_scores')
    this.setData({
      'score':score
    })
    {
    if (score<50) {
      this.setData({
        'txt':'合抱之木，生于毫末;九层之台，起于垒土;千里之行，始于足下。',
        'writer':'《道德经》'
      })
    }
    else if(score<100) {
      this.setData({
        'txt':'冰冻三尺，非一日之寒。',
        'writer':'王充《论衡》'
      })
    }
    else if(score<150) {
      this.setData({
        'txt':'最可怕的敌人，就是没有坚强的信念。',
        'writer':'罗曼·罗兰'
      })
    }
    else if(score<200) {
      this.setData({
        'txt':'苟有恒，何必三更起五更眠;最无益，只怕一日曝十日寒。',
        'writer':'毛泽东'
      })
    }
    else if(score<250) {
      this.setData({
        'txt':'一日一钱，十日十钱。绳锯木断，水滴石穿。',
        'writer':'班固'
      })
    }
    else if(score<300) {
      this.setData({
        'txt':'逆水行舟用力撑，一篙松劲退千寻。',
        'writer':'董必武'
      })
    }
    else if(score<350) {
      this.setData({
        'txt':'骐骥一跃，不能十步；驽马十驾，功在不舍。',
        'writer':'《荀子·劝学》'
      })
    }
    else if(score<400) {
      this.setData({
        'txt':'利用时间是一个极其高级的规律。',
        'writer':'恩格斯'
      })
    }
    else if(score<450) {
      this.setData({
        'txt':'天资的充分发挥和个人的勤学苦练是成正比例的。',
        'writer':'郭沫若'
      })
    }
    else if(score<500) {
      this.setData({
        'txt':'无聊，对于道德家来说是一个严重的问题，因为人类的罪过半数以上都是源于对它的恐惧。',
        'writer':'罗素'
      })
    }
    else if(score<550) {
      this.setData({
        'txt':'我喜欢读书，喜欢认识人，了解人。多读书，多认识人，多了解人，会扩大你的眼界，会使你变得善良些、纯洁些，或者对别人有用些。',
        'writer':'巴金'
      })
    }
    else if(score<600) {
      this.setData({
        'txt':'历史使人明智，诗歌使人聪慧，数学使人精确，哲学使人深刻，伦理使人庄重，逻辑使人善辩。',
        'writer':'培根'
      })
    }
    else if(score<650) {
      this.setData({
        'txt':'今天所做之事勿候明天，自己所做之事勿候他人。',
        'writer':'歌德'
      })
    }
    else if(score<700) {
      this.setData({
        'txt':'勤劳一日，可得一夜安眠;勤劳一生，可得幸福长眠。',
        'writer':'达·芬奇'
      })
    }
    else if(score<750) {
      this.setData({
        'txt':'以不息为体，以日新为道。',
        'writer':'唐·刘禹锡'
      })
    }
    else if(score<800) {
      this.setData({
        'txt':'自强为天下健，志刚为大君之道。',
        'writer':'清·康有为'
      })
    }
    else if(score<850) {
      this.setData({
        'txt':'君子敬其在已者，而不慕其在天者，是以日进也。',
        'writer':'荀子'
      })
    }
    else if(score<900) {
      this.setData({
        'txt':'路是脚踏出来的，历史是人写出来的。人的每一步行动都在书写自己的历史。',
        'writer':'吉鸿昌'
      })
    }
    else if(score<950) {
      this.setData({
        'txt':'道足以忘物之得春，志足以一气之盛衰。',
        'writer':'苏轼'
      })
    }
    else if(score<1000) {
      this.setData({
        'txt':'知人者智，自知者明。',
        'writer':'《老子》'
      })
    }
    else if(score>=1000) {
      this.setData({
        'txt':'会当凌绝顶，一览众山小',
        'writer':'开发团队全体'
      })
    }
    
  }
  }
})